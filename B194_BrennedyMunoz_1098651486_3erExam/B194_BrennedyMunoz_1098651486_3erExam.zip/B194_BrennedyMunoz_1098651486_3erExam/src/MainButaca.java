public class MainButaca {
    public static void main(String[] args) {
        Butaca but1 = new Butaca("Butaca PreColombina", 123456,
                (byte)3, "R123AsCircular",
               2f, 10f ,45f);

        but1.mostrarInformacion();
    }
}
