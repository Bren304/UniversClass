import java.util.Scanner;

public class main {
    public static void main(String[] args){

        float peso, estatura, imc;
        Scanner nd = new Scanner(System.in);

        System.out.println("Ingrese el peso de la persona");
        peso = nd.nextFloat();
        System.out.println("Ingrese la estatura de la pesona");
        estatura = nd.nextFloat();

        imcPaciente();
        nivelPesoPaciente();
    }

    public static Float imcPaciente (float peso, float estatura){
        float imc;
        String imcR;

        imc = peso/(estatura*estatura);
        return imc;
    }
    public static String nivelPesoPaciente(float imc){
        String nvpeso = "";
        if (imc < 18.5){
            nvpeso = "Bajo peso";
        }if (imc < 25){
            nvpeso = "Normal";
        }if (imc < 30){
            nvpeso = "Sobre peso";
        }if (imc >= 30){
            nvpeso = "Obesidad";
        }
        return nvpeso;
    }
}
