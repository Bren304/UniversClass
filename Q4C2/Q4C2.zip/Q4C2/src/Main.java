public class Main {
    public static void main(String[] args) {
        byte vectorPar[];
        vectorPar = new byte[10];
        byte []vectorImpar;
        vectorImpar = new byte[10];
        byte j=2, acu1 = 0, acu2 = 1;

        for (byte i = 0; i < vectorImpar.length; i++ ){
            acu1 = (byte) (acu1 + j);
            vectorPar[i] = acu1;
            System.out.println("vectoPar["+i+"] = " + vectorPar[i]);
            acu2 = (byte)(acu2+j);
            vectorImpar[i] = acu2;
            System.out.println("vectoImpar["+i+"] = " + vectorImpar[i]);
        }
    }
}